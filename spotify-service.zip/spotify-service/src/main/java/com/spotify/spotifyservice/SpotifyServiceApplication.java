package com.spotify.spotifyservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpotifyServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpotifyServiceApplication.class, args);
	}

}
