package com.spotify.spotifyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpotifyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
